package com.example.calculator

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.calculator.databinding.ActivityMainBinding
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Calculator state
    private val tokens = mutableListOf<String>() // sequence of numbers and operators, e.g. ["12", "+", "5"]
    private var currentInput = StringBuilder()   // the number currently being typed
    private var lastResult: BigDecimal? = null
    private var justEvaluated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNumberButtons()
        setupOperatorButtons()
        setupFunctionButtons()
        updateDisplay()
    }

    private fun setupNumberButtons() {
        val map = mapOf(
            binding.btn0 to "0", binding.btn1 to "1", binding.btn2 to "2",
            binding.btn3 to "3", binding.btn4 to "4", binding.btn5 to "5",
            binding.btn6 to "6", binding.btn7 to "7", binding.btn8 to "8",
            binding.btn9 to "9"
        )
        for ((button, digit) in map) {
            button.setOnClickListener { onDigit(digit) }
        }
        binding.btnDot.setOnClickListener { onDot() }
    }

    private fun setupOperatorButtons() {
        binding.btnPlus.setOnClickListener { onOperator("+") }
        binding.btnMinus.setOnClickListener { onOperator("−") }
        binding.btnMultiply.setOnClickListener { onOperator("×") }
        binding.btnDivide.setOnClickListener { onOperator("÷") }
        binding.btnEquals.setOnClickListener { onEquals() }
    }

    private fun setupFunctionButtons() {
        binding.btnClear.setOnClickListener { onClear() }
        binding.btnPlusMinus.setOnClickListener { onToggleSign() }
        binding.btnPercent.setOnClickListener { onPercent() }
    }

    private fun onDigit(digit: String) {
        if (justEvaluated) {
            // Start a fresh calculation after pressing '=' and then typing a digit
            tokens.clear()
            justEvaluated = false
        }
        if (digit == "0" && currentInput.toString() == "0") return
        if (currentInput.toString() == "0") {
            currentInput = StringBuilder(digit)
        } else {
            currentInput.append(digit)
        }
        updateDisplay()
    }

    private fun onDot() {
        if (justEvaluated) {
            tokens.clear()
            justEvaluated = false
            currentInput = StringBuilder()
        }
        if (currentInput.isEmpty()) {
            currentInput.append("0.")
        } else if (!currentInput.contains(".")) {
            currentInput.append(".")
        }
        updateDisplay()
    }

    private fun onOperator(op: String) {
        justEvaluated = false
        if (currentInput.isEmpty()) {
            // Allow changing the last operator instead of inserting a duplicate
            if (tokens.isNotEmpty() && isOperator(tokens.last())) {
                tokens[tokens.size - 1] = op
            }
            updateDisplay()
            return
        }
        tokens.add(currentInput.toString())
        tokens.add(op)
        currentInput = StringBuilder()
        updateDisplay()
    }

    private fun onEquals() {
        if (currentInput.isNotEmpty()) {
            tokens.add(currentInput.toString())
            currentInput = StringBuilder()
        }
        if (tokens.isEmpty()) return
        // Drop a trailing dangling operator, if any
        if (isOperator(tokens.last())) {
            tokens.removeAt(tokens.size - 1)
        }
        if (tokens.isEmpty()) return

        val result = evaluate(tokens)
        lastResult = result
        binding.tvExpression.text = tokens.joinToString(" ")
        currentInput = StringBuilder(formatNumber(result))
        tokens.clear()
        justEvaluated = true
        updateDisplay()
    }

    private fun onClear() {
        tokens.clear()
        currentInput = StringBuilder()
        lastResult = null
        justEvaluated = false
        binding.tvExpression.text = ""
        updateDisplay()
    }

    private fun onToggleSign() {
        if (currentInput.isNotEmpty()) {
            currentInput = if (currentInput.startsWith("-")) {
                StringBuilder(currentInput.substring(1))
            } else {
                StringBuilder("-" + currentInput)
            }
            updateDisplay()
        } else if (tokens.isNotEmpty() && !isOperator(tokens.last())) {
            val last = tokens.removeAt(tokens.size - 1)
            tokens.add(if (last.startsWith("-")) last.substring(1) else "-$last")
            updateDisplay()
        }
    }

    private fun onPercent() {
        if (currentInput.isNotEmpty()) {
            val value = currentInput.toString().toBigDecimalOrNull() ?: return
            val result = value.divide(BigDecimal(100))
            currentInput = StringBuilder(formatNumber(result))
            updateDisplay()
        }
    }

    private fun isOperator(token: String): Boolean = token in setOf("+", "−", "×", "÷")

    /**
     * Evaluates a flat list of tokens (numbers and operators) respecting standard
     * operator precedence: × and ÷ before + and −.
     */
    private fun evaluate(tokenList: List<String>): BigDecimal {
        // First pass: resolve × and ÷
        val pass1 = mutableListOf<String>()
        var i = 0
        while (i < tokenList.size) {
            val token = tokenList[i]
            if (token == "×" || token == "÷") {
                val left = pass1.removeAt(pass1.size - 1).toBigDecimal()
                val right = tokenList[i + 1].toBigDecimal()
                val result = if (token == "×") {
                    left.multiply(right)
                } else {
                    if (right.compareTo(BigDecimal.ZERO) == 0) {
                        BigDecimal.ZERO // avoid crash on divide-by-zero
                    } else {
                        left.divide(right, 10, RoundingMode.HALF_UP)
                    }
                }
                pass1.add(result.toPlainString())
                i += 2
            } else {
                pass1.add(token)
                i += 1
            }
        }

        // Second pass: resolve + and −
        var accumulator = pass1[0].toBigDecimal()
        i = 1
        while (i < pass1.size) {
            val op = pass1[i]
            val right = pass1[i + 1].toBigDecimal()
            accumulator = if (op == "+") accumulator.add(right) else accumulator.subtract(right)
            i += 2
        }
        return accumulator
    }

    private fun formatNumber(value: BigDecimal): String {
        val stripped = value.stripTrailingZeros()
        return if (stripped.scale() < 0) stripped.toPlainString() else stripped.toPlainString()
    }

    private fun updateDisplay() {
        val displayText = if (currentInput.isNotEmpty()) currentInput.toString()
        else if (tokens.isNotEmpty()) tokens.last()
        else "0"
        binding.tvResult.text = displayText

        if (!justEvaluated) {
            binding.tvExpression.text = tokens.joinToString(" ")
        }
    }
}
